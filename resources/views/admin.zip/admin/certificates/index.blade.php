@extends('admin.layouts.app')

@section('title', 'Certificate Verification')

@section('content')
<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="mb-0">Certificate Verification</h3>
            <small class="text-muted">
                Review and verify user certificates.
            </small>
        </div>
    </div>

    <div class="card shadow-sm">

        <div class="card-header bg-white">
            <form method="GET" action="{{ route('admin.certificates.index') }}">
                <div class="row g-3">

                    <div class="col-md-5">
                        <input type="text" name="search" class="form-control"
                            placeholder="Search user or certificate..." value="{{ $search }}">
                    </div>

                    <div class="col-md-3">
                        <select name="status" class="form-select">
                            <option value="">All Status</option>

                            <option value="pending" {{ $status=='pending' ? 'selected' : '' }}>
                                Pending
                            </option>

                            <option value="verified" {{ $status=='verified' ? 'selected' : '' }}>
                                Verified
                            </option>

                            <option value="rejected" {{ $status=='rejected' ? 'selected' : '' }}>
                                Rejected
                            </option>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <button class="btn btn-primary w-100" type="submit">
                            Search
                        </button>
                    </div>

                    <div class="col-md-2">
                        <a href="{{ route('admin.certificates.index') }}" class="btn btn-outline-secondary w-100">
                            Reset
                        </a>
                    </div>

                </div>
            </form>
        </div>

        <div class="card-body p-0">

            <table class="table table-hover align-middle mb-0">

                <thead class="table-light">
                    <tr>
                        <th>User</th>
                        <th>Certificate</th>
                        <th>Organization</th>
                        <th>Issue Date</th>
                        <th>Status</th>
                        <th width="120">Action</th>
                    </tr>
                </thead>

                <tbody>

                    @forelse($certifications as $certificate)

                    <tr>

                        <td>
                            {{ $certificate->user->name }}
                        </td>

                        <td>
                            {{ $certificate->name }}
                        </td>

                        <td>
                            {{ $certificate->organization }}
                        </td>

                        <td>
                            {{ $certificate->issue_date }}
                        </td>

                        <td>

                            @switch($certificate->verification_status)

                            @case('verified')
                            <span class="badge bg-success">
                                Verified
                            </span>
                            @break

                            @case('rejected')
                            <span class="badge bg-danger">
                                Rejected
                            </span>
                            @break

                            @default
                            <span class="badge bg-warning text-dark">
                                Pending
                            </span>

                            @endswitch

                        </td>

                        <td>

                            <a href="{{ route('admin.certificates.show', $certificate) }}"
                                class="btn btn-sm btn-primary">
                                View
                            </a>

                        </td>

                    </tr>

                    @empty

                    <tr>

                        <td colspan="6" class="text-center py-4">
                            No certificates found.
                        </td>

                    </tr>

                    @endforelse

                </tbody>

            </table>

        </div>

        @if($certifications->hasPages())

        <div class="card-footer bg-white">
            {{ $certifications->links() }}
        </div>

        @endif

    </div>

</div>
@endsection